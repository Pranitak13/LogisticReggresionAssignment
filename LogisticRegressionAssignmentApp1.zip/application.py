
# importing the necessary dependencies
from flask import Flask, render_template, request,jsonify
from flask_cors import CORS,cross_origin
import pandas as pd
import pickle
import numpy as np
from sklearn.preprocessing import StandardScaler

import statsmodels.api as sm
dta = sm.datasets.fair.load_pandas().data
application = Flask(__name__) # initializing a flask app

filename = 'modelForPrediction1.sav'
model1 = pickle.load(open(filename, 'rb'))  # loading the model file from the storage
# predictions using the loaded model file
dta = sm.datasets.fair.load_pandas().data
X = dta.iloc[:,:].values

@application.route('/')  # route to display the home page
@cross_origin()
def homePage():
    return render_template('index.html')

@application.route('/predict',methods=['POST']) # route to show the predictions in a web UI
@cross_origin()
def predict():
    '''
    For rendering results on HTML GUI
    '''
    float_features = [float(x) for x in request.form.values()]
    final_features = [np.array(float_features)]

    prediction = model1.predict(final_features)
    prediction1 = model1.predict_proba(final_features)
    print('prediction is', prediction)
    print('prediction is', prediction1)

    if prediction == 1:
        pred = "Woman is  having an affair."
    elif prediction == 0:
        pred = "Woman is not having an affair."
    output = pred

    return render_template('results.html', prediction_text='{}'.format(output))
if __name__ == "__main__":
    application.run(host='127.0.0.1', port=8001, debug=True)
	#app.run(debug=True) # running the app